<?php 
    include '../connection.php';
    $action=$_POST["action"];
    
    $response=array();

    if($action=='show_product')
    {
        $result=mysqli_query($conn,"select * from tbl_product as p left join tbl_category as c on c.category_id=p.category_id left join tbl_attribute as a on a.attribute_id=p.attribute_id where p.product_status='1' order by product_sequence ASC LIMIT 5") or die(mysqli_error($conn));
        
        //  $result=mysqli_query($conn,"select * from tbl_product as p left join tbl_category as c on c.category_id=p.category_id left join tbl_attribute as a on a.attribute_id=p.attribute_id where p.product_status='1' order by product_sequence desc") or die(mysqli_error($conn));
        if(mysqli_num_rows($result)<=0)
        {
            
            $response["status"]="no";
            $response["error"]="No Data Available!";
        }
        else
        {
            while($row=mysqli_fetch_assoc($result))
            {
                $response[]=$row;
            }
        }
    }
    elseif($action=='category_product')
    {
        $category_id=$_POST["category_id"];
        $result=mysqli_query($conn,"select * from tbl_product as p left join tbl_category as c on c.category_id=p.category_id left join tbl_attribute as a on a.attribute_id=p.attribute_id where p.category_id='$category_id' and p.product_status='1' order by product_sequence ASC") or die(mysqli_error($conn));
        if(mysqli_num_rows($result)<=0)
        {
            
            $response["status"]="no";
            $response["error"]="No Data Available!";
        }
        else
        {
            while($row=mysqli_fetch_assoc($result))
            {
                $response[]=$row;
            }
        }
    }
    elseif($action=='get_product_detail')
    {
        $product_id=$_POST["product_id"];
        $result=mysqli_query($conn,"select * from tbl_product as p left join tbl_category as c on c.category_id=p.category_id left join tbl_attribute as a on a.attribute_id=p.attribute_id where p.product_id='$product_id'") or die(mysqli_error($conn));
        if(mysqli_num_rows($result)<=0)
        {
            
            $response["status"]="no";
            $response["error"]="No Data Available!";
        }
        else
        {
            while($row=mysqli_fetch_assoc($result))
            {
                $response[]=array(
                    "product_id" => $row["product_id"],
                    "category_id" => $row["category_id"],
                    "category_name" => $row["category_name"],
                    "product_type" => $row["product_type"],
                    "attribute_id" => $row["attribute_id"],
                    "product_name" => $row["product_name"],
                    "product_image" => $row["product_image"],
                    "product_regular_price" => intval($row["product_regular_price"]),
                    "product_normal_price" => intval($row["product_normal_price"]),
                    "product_min_qty" => intval($row["product_min_qty"]),
                    // "product_price" => floatval($row["product_price"]),
                    // "product_price" => floatval($row["product_price"]),
                    "product_des" => $row["product_des"],
                    "product_status" => $row["product_status"],
                    "featured_product" => $row["featured_product"],
                    "attribute_name" => $row["attribute_name"],
                    "product_att_value" => $row["product_att_value"],
                    "attribute_status" => $row["attribute_status"],
                    );
            }
        }
    }
    else
    {
        $response["message"]="Something is Wrong";
    }
    echo json_encode($response);
?>