<?php 
    include '../connection.php';
    $response=array();

    $user_id=$_POST["user_id"];
    $timeslot="time_slot";
    $cutofftime="cutoff_time";
    $utype="user_type";
    $user_status="user_status";
    $user_balance="user_balance";
    $u_balance="u_balance";
    $min_balance="min_balance";
    $balance="200";
    $nagative_balance="accept_nagative_balance";
    //CATEGORY CODE
    
        $result1=mysqli_query($conn,"select * from tbl_user where user_id='$user_id'")or die(mysqli_error($conn));
        while($row=mysqli_fetch_assoc($result1))
        {
            $type = $row["user_type"];
            if($row["deliveryboy_id"]=='0')
            {
                $response[$timeslot]= "No";
                $response[$user_status]= $row["user_status"];
                $response[$user_balance]= $row["user_balance"];
                $response[$nagative_balance]= $row["accept_nagative_balance"];
                $response[$min_balance]= $balance;
            }
            else
            {
                $result=mysqli_query($conn,"select * from tbl_time_slot as t left join tbl_deliveryboy as d on d.time_slot_id=t.time_slot_id left join tbl_user as u on d.deliveryboy_id=u.deliveryboy_id where u.user_id='$user_id'")or die(mysqli_error($conn));
        
                while($rowq=mysqli_fetch_assoc($result))
                {
                    
                    // $response[]=$rowq;
                    $response[$timeslot]= $rowq["time_slot_name"];
                    $response[$cutofftime]= $rowq["time_slot_cutoff_time"];
                    $response[$user_status]= $rowq["user_status"];
                    $response[$user_balance]= $rowq["user_balance"];
                    $response[$nagative_balance]= $rowq["accept_nagative_balance"];
                    $response["user_first_name"]= $rowq["user_first_name"];
                    $response["user_last_name"]= $rowq["user_last_name"];
                    $response["user_subscription_status"]= $rowq["user_subscription_status"];
                    $response["user_last_name"]= $rowq["user_last_name"];
                    $response[$min_balance]= $balance;
                    $response[$utype]= $type;
                        
                }
            }
                
        }

        
    


    
    echo json_encode($response);
?>