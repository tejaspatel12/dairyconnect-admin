<?php 
    date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
    include '../../connection.php';

    $result=mysqli_query($conn,"insert into tbl_user (user_mobile_number) 
                values ('1122334433')") or die(mysqli_error($conn));
?>