<?php
date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
$date1 = "2021-11-30";
ECHO $new_date = date('D', strtotime($date1));
?>